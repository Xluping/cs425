package ch0.pk1;

import java.awt.EventQueue;

import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JOptionPane;

import java.awt.Font;
import javax.swing.JButton;
import java.awt.event.ActionListener;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.Statement;
import java.awt.event.ActionEvent;

public class Reward {

	private JFrame frame;

	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					Reward window = new Reward();
					window.frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	/**
	 * Create the application.
	 */
	public Reward() {
		initialize();
	}

	/**
	 * Initialize the contents of the frame.
	 */
	private void initialize() {
		frame = new JFrame();
		frame.setBounds(100, 100, 450, 300);
		frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		frame.getContentPane().setLayout(null);
		
		JLabel lblRewardPoints = new JLabel("Reward Points");
		lblRewardPoints.setFont(new Font("Tahoma", Font.PLAIN, 20));
		lblRewardPoints.setBounds(147, 11, 152, 37);
		frame.getContentPane().add(lblRewardPoints);
		
		JLabel lblTheRewardPoints = new JLabel("The reward points you have are more than 25.");
		lblTheRewardPoints.setFont(new Font("Tahoma", Font.PLAIN, 15));
		lblTheRewardPoints.setBounds(43, 73, 355, 25);
		frame.getContentPane().add(lblTheRewardPoints);
		
		JLabel lblDoYouWant = new JLabel("Do you want to use reward points for a free coffee ? ");
		lblDoYouWant.setFont(new Font("Tahoma", Font.PLAIN, 15));
		lblDoYouWant.setBounds(43, 123, 381, 25);
		frame.getContentPane().add(lblDoYouWant);
		
		JButton btnYes = new JButton("Yes");
		btnYes.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				try {
					
					Singleton single1 =Singleton.getInstance();
					int i = single1.getproid();
					int cus = single1.getcusid();
					
					Class.forName("com.mysql.jdbc.Driver");
					Connection con = DriverManager.getConnection("jdbc:mysql://localhost:3306/test", "root","");
					Statement stmt = con.createStatement();
					String sql = "update Product set numInStock = numInStock - 1 where productID = '"+ i +"'"; //'"+userID.getText()+"',
					int rs = stmt.executeUpdate(sql);
					String sql1 = "update Customer set availablePoints = availablePoints - 25 where customerID = '"+ cus +"'"; //'"+userID.getText()+"',
					int rs1 = stmt.executeUpdate(sql1);
					JOptionPane.showMessageDialog(null, "You will get a free coffee");
					
					Transaction1 tra = new Transaction1();
					Transaction1.main(null);
					frame.dispose();
				}
				
				//String sql = "Update Student set FirstName = '"+FirstName.getText()+"',LastName = '"+LastName.getText()+"',SID = '"+SID.getText()+"', Site = '"+Site.getText()+"',HW1 = '"+HW1.getText()+"',HW2 = '"+HW2.getText()+"',HW3 = '"+HW3.getText()+"',HW4 = '"+HW4.getText()+"',HW5 = '"+HW5.getText()+"', Project = '"+Project.getText()+"', Midterm = '"+Midterm.getText()+"', Final = '"+Final.getText()+"'";

			catch (Exception e1) {JOptionPane.showMessageDialog(null, e1);}
			}
		});
		btnYes.setBounds(73, 208, 89, 23);
		frame.getContentPane().add(btnYes);
		
		JButton btnNo = new JButton("No");
		btnNo.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				frame.dispose();
			}
		});
		btnNo.setBounds(247, 208, 89, 23);
		frame.getContentPane().add(btnNo);
	}

}
