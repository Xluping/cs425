package ch0.pk1;

import java.awt.EventQueue;

import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JOptionPane;

import java.awt.Font;
import javax.swing.JButton;
import javax.swing.JTextField;

import net.proteanit.sql.DbUtils;

import java.awt.event.ActionListener;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.Statement;
import java.awt.event.ActionEvent;
import javax.swing.JTable;
import javax.swing.JScrollPane;

public class Transaction1 {

	private JFrame frame;
	private JTextField cusID;
	private JTextField proID;
	private JTable table;
	private int i;
	private int i1;
	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					Transaction1 window = new Transaction1();
					window.frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	/**
	 * Create the application.
	 */
	public Transaction1() {
		initialize();
	}

	/**
	 * Initialize the contents of the frame.
	 */
	private void initialize() {
		frame = new JFrame();
		frame.setBounds(100, 100, 800, 550);
		frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		frame.getContentPane().setLayout(null);
		
		JLabel lblTransaction = new JLabel("Transaction");
		lblTransaction.setFont(new Font("Tahoma", Font.PLAIN, 20));
		lblTransaction.setBounds(334, 11, 115, 25);
		frame.getContentPane().add(lblTransaction);
		
		JLabel lblCustomerId = new JLabel("Customer ID :");
		lblCustomerId.setBounds(30, 70, 73, 14);
		frame.getContentPane().add(lblCustomerId);
		
		JLabel lblProductId = new JLabel("Product ID :");
		lblProductId.setBounds(336, 70, 58, 14);
		frame.getContentPane().add(lblProductId);
		
		JButton btnSubmit = new JButton("Submit");
		btnSubmit.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				try {
					
					Class.forName("com.mysql.jdbc.Driver");
					Connection con = DriverManager.getConnection("jdbc:mysql://localhost:3306/test", "root","");
					Statement stmt = con.createStatement();
					
					String sql = "insert into Transaction(customerID, productID) values((select customerID from Customer where customerID ='"+cusID.getText()+"'),(select productID from Product where productID ='"+proID.getText()+"'))"; //'"+userID.getText()+"',
					int rs = stmt.executeUpdate(sql);
					
					String sql2 = "update Product set numInStock = numInStock - 1 where productID = '"+ proID.getText() +"'"; //'"+userID.getText()+"',
					int rs2 = stmt.executeUpdate(sql2);
					String sql1 = "update Customer inner join Transaction inner join Product set availablePoints = availablePoints + (Select price from Product where productID = '"+proID.getText()+"'), lifetimePoints = lifetimePoints + (Select price from Product where productID = '"+proID.getText()+"') where Customer.customerID = '"+ cusID.getText() +"'"; //'"+userID.getText()+"',
					int rs1 = stmt.executeUpdate(sql1);
					
					JOptionPane.showMessageDialog(null, "Transaction successfully");
				}
				
				//String sql = "Update Student set FirstName = '"+FirstName.getText()+"',LastName = '"+LastName.getText()+"',SID = '"+SID.getText()+"', Site = '"+Site.getText()+"',HW1 = '"+HW1.getText()+"',HW2 = '"+HW2.getText()+"',HW3 = '"+HW3.getText()+"',HW4 = '"+HW4.getText()+"',HW5 = '"+HW5.getText()+"', Project = '"+Project.getText()+"', Midterm = '"+Midterm.getText()+"', Final = '"+Final.getText()+"'";

			catch (Exception e1) {JOptionPane.showMessageDialog(null, e1);}
				
			}
		});
		btnSubmit.setBounds(218, 428, 89, 23);
		frame.getContentPane().add(btnSubmit);
		
		JButton btnBack = new JButton("Back");
		btnBack.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				Transaction tran = new Transaction();
				Transaction.main(null);
				frame.dispose();
			}
			
		});
		btnBack.setBounds(487, 428, 89, 23);
		frame.getContentPane().add(btnBack);
		
		cusID = new JTextField();
		cusID.setColumns(10);
		cusID.setBounds(114, 67, 193, 20);
		frame.getContentPane().add(cusID);
		
		proID = new JTextField();
		proID.setColumns(10);
		proID.setBounds(404, 67, 193, 20);
		frame.getContentPane().add(proID);
		
		JButton btnLoad = new JButton("Load");
		btnLoad.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				
				try {
					Class.forName("com.mysql.jdbc.Driver");
					Connection con = DriverManager.getConnection("jdbc:mysql://localhost:3306/test", "root","");
					Statement stmt = con.createStatement();
					String sql = "Select Customer.customerID,firstName, lastName, availablePoints, Product.productID, name, price, numInStock from Product inner join Customer where productID = '"+proID.getText()+"' and customerID = '"+cusID.getText()+"'";
					//	PreparedStatement pst = con.prepareStatement(sql);
					ResultSet rs = stmt.executeQuery(sql);
					table.setModel(DbUtils.resultSetToTableModel(rs));
					
					String sql0 = "Select availablePoints from Customer where customerID = '"+cusID.getText()+"'";
					ResultSet rs0 = stmt.executeQuery(sql0);
					if (rs0.next()) {
					i =rs0.getInt(1);
						if(i>=25) {
							Reward rew = new Reward();
							Reward.main(null);
							String sql2 = "Select productID from Product where productID = '"+proID.getText()+"'";
							ResultSet rs2 = stmt.executeQuery(sql2);
							if (rs2.next()) {
								i1 =rs2.getInt(1);
								Singleton single1 =Singleton.getInstance();
								single1.proid(i1);
							}
							
							String sql3 = "Select customerID from Customer where customerID = '"+proID.getText()+"'";
							ResultSet rs3 = stmt.executeQuery(sql3);
							if (rs3.next()) {
								i1 =rs3.getInt(1);
								Singleton single1 =Singleton.getInstance();
								single1.cusid(i1);
							}
							
						} 
					}
					
					
				}
				
			catch (Exception e1) {JOptionPane.showMessageDialog(null, e1);}	
			}
		});
		btnLoad.setBounds(652, 66, 89, 23);
		frame.getContentPane().add(btnLoad);
		
		JScrollPane scrollPane = new JScrollPane();
		scrollPane.setBounds(30, 119, 711, 273);
		frame.getContentPane().add(scrollPane);
		
		table = new JTable();
		scrollPane.setViewportView(table);
	}

}
