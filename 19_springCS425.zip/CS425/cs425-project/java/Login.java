package ch0.pk1;

import java.awt.EventQueue;

import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JOptionPane;

import java.awt.Font;
import javax.swing.ImageIcon;
import javax.swing.JTextField;
import javax.swing.JPasswordField;
import javax.swing.JButton;
import java.awt.event.ActionListener;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.Statement;
import java.sql.Timestamp;
import java.util.Calendar;
import java.util.Date;
import java.awt.event.ActionEvent;

public class Login {

	private JFrame frame;
	private JTextField userID;
	private JPasswordField password;
	public String userid;

	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					Login window = new Login();
					window.frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	/**
	 * Create the application.
	 */
	public Login() {
		initialize();
	}
	
	public String getID() {
		return this.userid;
	}

	/**
	 * Initialize the contents of the frame.
	 */
	private void initialize() {
		frame = new JFrame();
		frame.setBounds(100, 100, 450, 350);
		frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		frame.getContentPane().setLayout(null);
		
		JLabel lblLogin = new JLabel("Login");
		lblLogin.setIcon(new ImageIcon("C:\\Users\\bxie9\\Desktop\\256x256bb.jpg"));
		lblLogin.setBounds(93, 0, 249, 77);
		frame.getContentPane().add(lblLogin);
		
		JLabel lblUsername = new JLabel("User ID :");
		lblUsername.setFont(new Font("Tahoma", Font.PLAIN, 15));
		lblUsername.setBounds(53, 111, 88, 25);
		frame.getContentPane().add(lblUsername);
		
		JLabel lblPassword = new JLabel("Password :");
		lblPassword.setFont(new Font("Tahoma", Font.PLAIN, 15));
		lblPassword.setBounds(53, 173, 88, 25);
		frame.getContentPane().add(lblPassword);
		
		userID = new JTextField();
		userID.setBounds(151, 115, 191, 20);
		frame.getContentPane().add(userID);
		userID.setColumns(10);
		
		password = new JPasswordField();
		password.setBounds(151, 177, 191, 20);
		frame.getContentPane().add(password);
		
		JButton Login = new JButton("Login");
		Login.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				try {
					Class.forName("com.mysql.jdbc.Driver");
					Connection con = DriverManager.getConnection("jdbc:mysql://localhost:3306/test", "root","");
					Statement stmt = con.createStatement();
					
		
					String sql = "Select * from user1 where userID = '"+userID.getText()+"' and Password='"+password.getText()+"'";
					ResultSet rs = stmt.executeQuery(sql);
					//String password = txtpassword.getText();
					//String username = txtusername.getText();
					userid = userID.getText();
					
					Singleton single = Singleton.getInstance();
					single.userid(userid);
					
					
					if(rs.next()) {
						/*userID.setText(null);
						password.setText(null);*/
						//setVisible(false);
						
						// (2) create a java timestamp object that represents the current time (i.e., a "current timestamp")
					    Calendar calendar = Calendar.getInstance();
					 //   java.sql.Timestamp ourJavaTimestampObject0 = new java.sql.Timestamp(calendar.getTime().getTime());
					    
					    
					    // (3) create a java timestamp insert statement
				/*	    String sqlTimestampInsertStatement = "INSERT INTO Session VALUES ('"+userID.getText()+"',?,?)";
					    PreparedStatement preparedStatement = con.prepareStatement(sqlTimestampInsertStatement);
					    preparedStatement.setTimestamp(1, ourJavaTimestampObject);
					    preparedStatement.setTimestamp(2, ourJavaTimestampObject);
					    preparedStatement.executeUpdate();
					    
						 System.out.println(ourJavaTimestampObject);*/
						
						Home object = new Home();
						//object.setVisible(true);
						Home.main(null);
						Home.ourJavaTimestampObject0 = new java.sql.Timestamp(calendar.getTime().getTime());;
						frame.dispose();
						
					}
					
				}catch (Exception e1) {JOptionPane.showMessageDialog(null, e1);}
			}
		});
		Login.setBounds(91, 243, 89, 23);
		frame.getContentPane().add(Login);
		
		JButton Reset = new JButton("Reset");
		Reset.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				userID.setText(null);
				password.setText(null);
				
			}
		});
		Reset.setBounds(253, 243, 89, 23);
		frame.getContentPane().add(Reset);
	}
}
