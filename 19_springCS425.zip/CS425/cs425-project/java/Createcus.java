package ch0.pk1;

import java.awt.EventQueue;

import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JOptionPane;

import java.awt.Font;
import javax.swing.JButton;
import javax.swing.JTextField;
import java.awt.event.ActionListener;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.Statement;
import java.awt.event.ActionEvent;

public class Createcus {

	private JFrame frame;
	private JTextField availpoint;
	private JTextField lifepoint;
	private JTextField addr;
	private JTextField lastname;
	private JTextField firstname;

	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					Createcus window = new Createcus();
					window.frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	/**
	 * Create the application.
	 */
	public Createcus() {
		initialize();
	}

	/**
	 * Initialize the contents of the frame.
	 */
	private void initialize() {
		frame = new JFrame();
		frame.setBounds(100, 100, 450, 450);
		frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		frame.getContentPane().setLayout(null);
		
		JLabel lblCreate = new JLabel("Create");
		lblCreate.setFont(new Font("Tahoma", Font.PLAIN, 20));
		lblCreate.setBounds(184, 11, 73, 25);
		frame.getContentPane().add(lblCreate);
		
		JLabel lblFirstName = new JLabel("First Name : ");
		lblFirstName.setBounds(63, 69, 73, 14);
		frame.getContentPane().add(lblFirstName);
		
		JLabel lblLastName = new JLabel("Last Name :");
		lblLastName.setBounds(63, 118, 73, 14);
		frame.getContentPane().add(lblLastName);
		
		JLabel lblAddress = new JLabel("Address : ");
		lblAddress.setBounds(63, 175, 73, 14);
		frame.getContentPane().add(lblAddress);
		
		JLabel lblLifetimePoints = new JLabel("Lifetime Points :");
		lblLifetimePoints.setBounds(63, 233, 83, 14);
		frame.getContentPane().add(lblLifetimePoints);
		
		JLabel lblAvailablePoints = new JLabel("Available Points :");
		lblAvailablePoints.setBounds(63, 283, 83, 14);
		frame.getContentPane().add(lblAvailablePoints);
		
		JButton btnSubmit = new JButton("Submit");
		btnSubmit.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				try {
					Class.forName("com.mysql.jdbc.Driver");
					Connection con = DriverManager.getConnection("jdbc:mysql://localhost:3306/test", "root","");
					Statement stmt = con.createStatement();
					String sql = "insert into Customer(firstName,lastName,address,lifetimePoints,availablePoints) values( '"+firstname.getText()+"', '"+lastname.getText()+"', '"+addr.getText()+"',  '"+lifepoint.getText()+"', '"+availpoint.getText()+"')";
					int rs = stmt.executeUpdate(sql);
					JOptionPane.showMessageDialog(null, "The record input successfully");
				}
				
				//String sql = "Update Student set FirstName = '"+FirstName.getText()+"',LastName = '"+LastName.getText()+"',SID = '"+SID.getText()+"', Site = '"+Site.getText()+"',HW1 = '"+HW1.getText()+"',HW2 = '"+HW2.getText()+"',HW3 = '"+HW3.getText()+"',HW4 = '"+HW4.getText()+"',HW5 = '"+HW5.getText()+"', Project = '"+Project.getText()+"', Midterm = '"+Midterm.getText()+"', Final = '"+Final.getText()+"'";

			catch (Exception e1) {JOptionPane.showMessageDialog(null, e1);}
			}
		});
		btnSubmit.setBounds(95, 341, 89, 23);
		frame.getContentPane().add(btnSubmit);
		
		JButton btnBack = new JButton("Back");
		btnBack.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				Customer cus = new Customer();
				Customer.main(null);
				frame.dispose();
			}
		});
		btnBack.setBounds(245, 341, 89, 23);
		frame.getContentPane().add(btnBack);
		
		availpoint = new JTextField();
		availpoint.setBounds(156, 280, 200, 20);
		frame.getContentPane().add(availpoint);
		availpoint.setColumns(10);
		
		lifepoint = new JTextField();
		lifepoint.setColumns(10);
		lifepoint.setBounds(156, 230, 200, 20);
		frame.getContentPane().add(lifepoint);
		
		addr = new JTextField();
		addr.setColumns(10);
		addr.setBounds(156, 172, 200, 20);
		frame.getContentPane().add(addr);
		
		lastname = new JTextField();
		lastname.setColumns(10);
		lastname.setBounds(156, 115, 200, 20);
		frame.getContentPane().add(lastname);
		
		firstname = new JTextField();
		firstname.setColumns(10);
		firstname.setBounds(156, 66, 200, 20);
		frame.getContentPane().add(firstname);
	}

}
