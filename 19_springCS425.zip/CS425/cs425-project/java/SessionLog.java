package ch0.pk1;

import java.awt.EventQueue;

import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JOptionPane;

import java.awt.Font;
import javax.swing.JTextField;
import javax.swing.JButton;
import java.awt.event.ActionListener;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.Statement;
import java.awt.event.ActionEvent;

public class SessionLog {

	private JFrame frame;
	private JTextField userID;
	private JTextField Login;
	private JTextField Logout;

	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					SessionLog window = new SessionLog();
					window.frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	/**
	 * Create the application.
	 */
	public SessionLog() {
		initialize();
	}

	/**
	 * Initialize the contents of the frame.
	 */
	private void initialize() {
		frame = new JFrame();
		frame.setBounds(100, 100, 450, 310);
		frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		frame.getContentPane().setLayout(null);
		
		JLabel lblLogin = new JLabel("Login");
		lblLogin.setFont(new Font("Tahoma", Font.PLAIN, 20));
		lblLogin.setBounds(190, 11, 72, 32);
		frame.getContentPane().add(lblLogin);
		
		JLabel lblUserId = new JLabel("User ID :");
		lblUserId.setBounds(56, 74, 60, 20);
		frame.getContentPane().add(lblUserId);
		
		JLabel lblLoginTime = new JLabel("Login Time :");
		lblLoginTime.setBounds(56, 121, 72, 20);
		frame.getContentPane().add(lblLoginTime);
		
		JLabel lblLogoutTime = new JLabel("Logout Time :");
		lblLogoutTime.setBounds(56, 172, 72, 14);
		frame.getContentPane().add(lblLogoutTime);
		
		userID = new JTextField();
		userID.setBounds(142, 74, 214, 20);
		frame.getContentPane().add(userID);
		userID.setColumns(10);
		
		Login = new JTextField();
		Login.setColumns(10);
		Login.setBounds(142, 121, 214, 20);
		frame.getContentPane().add(Login);
		
		Logout = new JTextField();
		Logout.setColumns(10);
		Logout.setBounds(142, 169, 214, 20);
		frame.getContentPane().add(Logout);
		
		JButton btnSubmit = new JButton("Submit");
		btnSubmit.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				try {
					Class.forName("com.mysql.jdbc.Driver");
					Connection con = DriverManager.getConnection("jdbc:mysql://localhost:3306/test", "root","");
					Statement stmt = con.createStatement();
					String sql = "insert into Session values((select userID from User1 where userID ='"+userID.getText()+"'),'"+Login.getText()+"', '"+Logout.getText()+"')"; //'"+userID.getText()+"',
					int rs = stmt.executeUpdate(sql);
					JOptionPane.showMessageDialog(null, "The record input successfully");
				}
				
				//String sql = "Update Student set FirstName = '"+FirstName.getText()+"',LastName = '"+LastName.getText()+"',SID = '"+SID.getText()+"', Site = '"+Site.getText()+"',HW1 = '"+HW1.getText()+"',HW2 = '"+HW2.getText()+"',HW3 = '"+HW3.getText()+"',HW4 = '"+HW4.getText()+"',HW5 = '"+HW5.getText()+"', Project = '"+Project.getText()+"', Midterm = '"+Midterm.getText()+"', Final = '"+Final.getText()+"'";

			catch (Exception e1) {JOptionPane.showMessageDialog(null, e1);}
			}
		});
		btnSubmit.setBounds(94, 221, 89, 23);
		frame.getContentPane().add(btnSubmit);
		
		JButton btnBack = new JButton("Back");
		btnBack.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				Session ses = new Session();
				Session.main(null);
				frame.dispose();
			}
		});
		btnBack.setBounds(244, 221, 89, 23);
		frame.getContentPane().add(btnBack);
	}

}
