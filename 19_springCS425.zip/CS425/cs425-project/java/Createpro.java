package ch0.pk1;

import java.awt.EventQueue;

import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JOptionPane;

import java.awt.Font;
import javax.swing.JButton;
import javax.swing.JTextField;
import java.awt.event.ActionListener;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.Statement;
import java.awt.event.ActionEvent;

public class Createpro {

	private JFrame frame;
	private JTextField Name;
	private JTextField Price;
	private JTextField Number;
	private JTextField Category;

	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					Createpro window = new Createpro();
					window.frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	/**
	 * Create the application.
	 */
	public Createpro() {
		initialize();
	}

	/**
	 * Initialize the contents of the frame.
	 */
	private void initialize() {
		frame = new JFrame();
		frame.setBounds(100, 100, 450, 400);
		frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		frame.getContentPane().setLayout(null);
		
		JLabel lblCreate = new JLabel("Create");
		lblCreate.setFont(new Font("Tahoma", Font.PLAIN, 20));
		lblCreate.setBounds(185, 11, 77, 25);
		frame.getContentPane().add(lblCreate);
		
		JLabel lblName = new JLabel("Name :");
		lblName.setBounds(72, 81, 46, 14);
		frame.getContentPane().add(lblName);
		
		JLabel lblPrice = new JLabel("Price :");
		lblPrice.setBounds(72, 136, 46, 14);
		frame.getContentPane().add(lblPrice);
		
		JLabel lblNewLabel = new JLabel("Number :");
		lblNewLabel.setBounds(72, 196, 61, 14);
		frame.getContentPane().add(lblNewLabel);
		
		JLabel lblNewLabel_1 = new JLabel("Category :");
		lblNewLabel_1.setBounds(72, 250, 61, 14);
		frame.getContentPane().add(lblNewLabel_1);
		
		JButton btnSubmit = new JButton("Submit");
		btnSubmit.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				try {
					Class.forName("com.mysql.jdbc.Driver");
					Connection con = DriverManager.getConnection("jdbc:mysql://localhost:3306/test", "root","");
					Statement stmt = con.createStatement();
					String sql = "insert into Product(name,price,numInStock,category) values( '"+Name.getText()+"', '"+Price.getText()+"',  '"+Number.getText()+"', '"+Category.getText()+"')";
					int rs = stmt.executeUpdate(sql);
					JOptionPane.showMessageDialog(null, "The record input successfully");
				}
				
				//String sql = "Update Student set FirstName = '"+FirstName.getText()+"',LastName = '"+LastName.getText()+"',SID = '"+SID.getText()+"', Site = '"+Site.getText()+"',HW1 = '"+HW1.getText()+"',HW2 = '"+HW2.getText()+"',HW3 = '"+HW3.getText()+"',HW4 = '"+HW4.getText()+"',HW5 = '"+HW5.getText()+"', Project = '"+Project.getText()+"', Midterm = '"+Midterm.getText()+"', Final = '"+Final.getText()+"'";

			catch (Exception e1) {JOptionPane.showMessageDialog(null, e1);}
			}
		});
		btnSubmit.setBounds(95, 301, 89, 23);
		frame.getContentPane().add(btnSubmit);
		
		JButton btnBack = new JButton("Back");
		btnBack.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				Production pro = new Production();
				Production.main(null);
				frame.dispose();
			}
		});
		btnBack.setBounds(239, 301, 89, 23);
		frame.getContentPane().add(btnBack);
		
		Name = new JTextField();
		Name.setColumns(10);
		Name.setBounds(143, 78, 211, 20);
		frame.getContentPane().add(Name);
		
		Price = new JTextField();
		Price.setColumns(10);
		Price.setBounds(143, 133, 211, 20);
		frame.getContentPane().add(Price);
		
		Number = new JTextField();
		Number.setColumns(10);
		Number.setBounds(143, 193, 211, 20);
		frame.getContentPane().add(Number);
		
		Category = new JTextField();
		Category.setColumns(10);
		Category.setBounds(143, 247, 211, 20);
		frame.getContentPane().add(Category);
	}

}
