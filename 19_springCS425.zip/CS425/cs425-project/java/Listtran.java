package ch0.pk1;

import java.awt.EventQueue;

import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JOptionPane;

import java.awt.Font;
import javax.swing.JTable;

import net.proteanit.sql.DbUtils;

import javax.swing.JScrollPane;
import javax.swing.JButton;
import java.awt.event.ActionListener;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.Statement;
import java.awt.event.ActionEvent;

public class Listtran {

	private JFrame frame;
	private JTable table;

	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					Listtran window = new Listtran();
					window.frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	/**
	 * Create the application.
	 */
	public Listtran() {
		initialize();
	}

	/**
	 * Initialize the contents of the frame.
	 */
	private void initialize() {
		frame = new JFrame();
		frame.setBounds(100, 100, 800, 400);
		frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		frame.getContentPane().setLayout(null);
		
		JLabel lblList = new JLabel("List");
		lblList.setFont(new Font("Tahoma", Font.PLAIN, 20));
		lblList.setBounds(384, 11, 62, 25);
		frame.getContentPane().add(lblList);
		
		JScrollPane scrollPane = new JScrollPane();
		scrollPane.setBounds(46, 57, 692, 237);
		frame.getContentPane().add(scrollPane);
		
		table = new JTable();
		scrollPane.setViewportView(table);
		
		JButton btnSubmit = new JButton("Load");
		btnSubmit.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				try {
					Class.forName("com.mysql.jdbc.Driver");
					Connection con = DriverManager.getConnection("jdbc:mysql://localhost:3306/test", "root","");
					Statement stmt = con.createStatement();
					String sql = "Select * from Transaction";
				//	PreparedStatement pst = con.prepareStatement(sql);
					ResultSet rs = stmt.executeQuery(sql);
					table.setModel(DbUtils.resultSetToTableModel(rs));
				}
				
			catch (Exception e1) {JOptionPane.showMessageDialog(null, e1);}	
			}
		});
		btnSubmit.setBounds(216, 315, 89, 23);
		frame.getContentPane().add(btnSubmit);
		
		JButton btnBack = new JButton("Back");
		btnBack.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				Transaction tran = new Transaction();
				Transaction.main(null);
				frame.dispose();
			}
		});
		btnBack.setBounds(490, 315, 89, 23);
		frame.getContentPane().add(btnBack);
	}

}
