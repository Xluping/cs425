package ch0.pk1;

import java.awt.EventQueue;

import javax.swing.JFrame;
import javax.swing.JLabel;
import java.awt.Font;
import javax.swing.JButton;
import java.awt.event.ActionListener;
import java.awt.event.ActionEvent;

public class Transaction {

	private JFrame frame;

	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					Transaction window = new Transaction();
					window.frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	/**
	 * Create the application.
	 */
	public Transaction() {
		initialize();
	}

	/**
	 * Initialize the contents of the frame.
	 */
	private void initialize() {
		frame = new JFrame();
		frame.setBounds(100, 100, 450, 300);
		frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		frame.getContentPane().setLayout(null);
		
		JLabel lblTransaction = new JLabel("Transaction");
		lblTransaction.setFont(new Font("Tahoma", Font.PLAIN, 20));
		lblTransaction.setBounds(161, 11, 113, 33);
		frame.getContentPane().add(lblTransaction);
		
		JButton btnTransaction = new JButton("Transaction");
		btnTransaction.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				Transaction1 tran1 = new Transaction1();
				Transaction1.main(null);
				frame.dispose();
			}
		});
		btnTransaction.setBounds(73, 91, 113, 40);
		frame.getContentPane().add(btnTransaction);
		
		JButton btnList = new JButton("list");
		btnList.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				Listtran listtran =  new Listtran();
				Listtran.main(null);
				frame.dispose();
			}
		});
		btnList.setBounds(238, 91, 113, 40);
		frame.getContentPane().add(btnList);
		
		JButton btnBack = new JButton("Back");
		btnBack.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				Home home = new Home();
				Home.main(null);
				frame.dispose();
			}
		});
		btnBack.setBounds(164, 195, 89, 23);
		frame.getContentPane().add(btnBack);
	}

}
