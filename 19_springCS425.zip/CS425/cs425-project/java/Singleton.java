package ch0.pk1;

import java.sql.Time;
import java.util.Calendar;

public class Singleton {
	private String userid;
	private int i;
	private int cus;

	private static Singleton instance;  
    private Singleton (){}  
    public static synchronized Singleton getInstance() {  
    if (instance == null) {  
        instance = new Singleton();  
    }  
    return instance;  
    }  

    public void userid(String str) {
    	userid = str;
    }
    
    public String getid() {
    	return this.userid;
    }
    
    public void proid(int id) {
    	i = id;
    }
    
    public int getproid() {
    	return this.i;
    }
    
    public void cusid(int id) {
    	cus = id;
    }
    
    public int getcusid() {
    	return this.cus;
    }
    
}
