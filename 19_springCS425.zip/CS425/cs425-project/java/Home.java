package ch0.pk1;

import java.awt.EventQueue;

import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.ImageIcon;
import javax.swing.JButton;
import java.awt.event.ActionListener;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.Statement;
import java.util.Calendar;
import java.awt.event.ActionEvent;

public class Home {
	
	public static java.sql.Timestamp ourJavaTimestampObject0;

	private JFrame frame;

	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					Home window = new Home();
					window.frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	/**
	 * Create the application.
	 */
	public Home() {
		initialize();
	}

	/**
	 * Initialize the contents of the frame.
	 */
	private void initialize() {
		frame = new JFrame();
		frame.setBounds(100, 100, 450, 550);
		frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		frame.getContentPane().setLayout(null);
		
		JLabel lblNewLabel = new JLabel("New label");
		lblNewLabel.setIcon(new ImageIcon("C:\\Users\\bxie9\\Desktop\\256x256bb.jpg"));
		lblNewLabel.setBounds(86, 11, 259, 84);
		frame.getContentPane().add(lblNewLabel);
		
		JButton btnUser = new JButton("User");
		btnUser.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				User user = new User();
				User.main(null);
				frame.dispose();
			}
		});
		btnUser.setBounds(69, 146, 112, 54);
		frame.getContentPane().add(btnUser);
		
		JButton btnSession = new JButton("Session");
		btnSession.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				Session sess = new Session();
				Session.main(null);
				frame.dispose();
			}
		});
		btnSession.setBounds(244, 146, 112, 54);
		frame.getContentPane().add(btnSession);
		
		JButton btnCustomer = new JButton("Customer");
		btnCustomer.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				Customer cus = new Customer();
				Customer.main(null);
				frame.dispose();
			}
		});
		btnCustomer.setBounds(69, 270, 112, 54);
		frame.getContentPane().add(btnCustomer);
		
		JButton btnTransaction = new JButton("Transaction");
		btnTransaction.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				Transaction tran = new Transaction();
				Transaction.main(null);
				frame.dispose();
			}
		});
		btnTransaction.setBounds(244, 270, 112, 54);
		frame.getContentPane().add(btnTransaction);
		
		JButton btnProduct = new JButton("Product");
		btnProduct.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				Production pro = new Production();
				Production.main(null);
				frame.dispose();
			}
		});
		btnProduct.setBounds(69, 396, 112, 54);
		frame.getContentPane().add(btnProduct);
		
		JButton btnBack = new JButton("Back");
		btnBack.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				try {
					
				
					String logid = null;
					Singleton single =Singleton.getInstance();
					logid = single.getid();
					
				Class.forName("com.mysql.jdbc.Driver");
				Connection con = DriverManager.getConnection("jdbc:mysql://localhost:3306/test", "root","");
				Statement stmt = con.createStatement();
				
				Calendar calendar = Calendar.getInstance();
			    java.sql.Timestamp ourJavaTimestampObject = new java.sql.Timestamp(calendar.getTime().getTime());
			   
			    
			    String sqlTimestampInsertStatement = "INSERT INTO Session VALUES ('"+logid+"',?,?)";
			    PreparedStatement preparedStatement = con.prepareStatement(sqlTimestampInsertStatement);
			    preparedStatement.setTimestamp(1, ourJavaTimestampObject0);
			    preparedStatement.setTimestamp(2, ourJavaTimestampObject);
			    preparedStatement.executeUpdate();
			    
			    System.out.println(ourJavaTimestampObject);
				
			}
			    catch (Exception e1) {JOptionPane.showMessageDialog(null, e1);}
			    
				Login log = new Login();
				Login.main(null);
				frame.dispose();
			}
		});
		btnBack.setBounds(244, 396, 112, 54);
		frame.getContentPane().add(btnBack);
	}

}
