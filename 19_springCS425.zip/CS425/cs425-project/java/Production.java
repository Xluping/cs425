package ch0.pk1;

import java.awt.EventQueue;

import javax.swing.JFrame;
import javax.swing.JLabel;
import java.awt.Font;
import javax.swing.JButton;
import java.awt.event.ActionListener;
import java.awt.event.ActionEvent;

public class Production {

	private JFrame frame;

	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					Production window = new Production();
					window.frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	/**
	 * Create the application.
	 */
	public Production() {
		initialize();
	}

	/**
	 * Initialize the contents of the frame.
	 */
	private void initialize() {
		frame = new JFrame();
		frame.setBounds(100, 100, 450, 300);
		frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		frame.getContentPane().setLayout(null);
		
		JLabel lblProduct = new JLabel("Production");
		lblProduct.setFont(new Font("Tahoma", Font.PLAIN, 20));
		lblProduct.setBounds(167, 11, 111, 32);
		frame.getContentPane().add(lblProduct);
		
		JButton btnCreate = new JButton("create");
		btnCreate.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				Createpro createpro = new Createpro();
				Createpro.main(null);
				frame.dispose();
				
			}
		});
		btnCreate.setBounds(64, 90, 94, 41);
		frame.getContentPane().add(btnCreate);
		
		JButton btnlist = new JButton("list");
		btnlist.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				Listpro listpro =  new Listpro();
				Listpro.main(null);
				frame.dispose();
			}
		});
		btnlist.setBounds(244, 90, 94, 41);
		frame.getContentPane().add(btnlist);
		
		JButton btnBacl = new JButton("Back");
		btnBacl.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				Home home = new Home();
				Home.main(null);
				frame.dispose();
			}
		});
		btnBacl.setBounds(172, 199, 89, 23);
		frame.getContentPane().add(btnBacl);
	}

}
