/*
 Navicat Premium Data Transfer

 Source Server         : localhost_mysql
 Source Server Type    : MySQL
 Source Server Version : 80017
 Source Host           : localhost:3306
 Source Schema         : cs425

 Target Server Type    : MySQL
 Target Server Version : 80017
 File Encoding         : 65001

 Date: 05/12/2019 20:21:40
*/

SET NAMES utf8mb4;
SET FOREIGN_KEY_CHECKS = 0;

-- ----------------------------
-- Table structure for credit
-- ----------------------------
DROP TABLE IF EXISTS `credit`;
CREATE TABLE `credit` (
  `user_id` int(11) DEFAULT NULL,
  `credit` double(255,0) DEFAULT '0',
  KEY `id` (`user_id`),
  CONSTRAINT `id` FOREIGN KEY (`user_id`) REFERENCES `users` (`user_id`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

-- ----------------------------
-- Table structure for login_info
-- ----------------------------
DROP TABLE IF EXISTS `login_info`;
CREATE TABLE `login_info` (
  `info_id` int(11) NOT NULL AUTO_INCREMENT,
  `info_user` varchar(255) NOT NULL,
  `info_time` datetime DEFAULT NULL,
  PRIMARY KEY (`info_id`)
) ENGINE=InnoDB AUTO_INCREMENT=171 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

-- ----------------------------
-- Table structure for orders
-- ----------------------------
DROP TABLE IF EXISTS `orders`;
CREATE TABLE `orders` (
  `order_id` int(11) NOT NULL AUTO_INCREMENT,
  `order_item` varchar(255) DEFAULT NULL,
  `order_price` decimal(10,2) DEFAULT NULL,
  `order_user_id` int(255) DEFAULT NULL,
  `order_user_address` varchar(255) DEFAULT NULL,
  `order_user_city` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci DEFAULT NULL,
  `order_user_postcode` varchar(6) CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci DEFAULT NULL,
  `order_user_credit` varchar(255) DEFAULT NULL,
  `order_placed_time` datetime DEFAULT NULL,
  `order_ship_id` varchar(255) DEFAULT NULL,
  `order_status` int(255) DEFAULT NULL COMMENT '0:canceled',
  PRIMARY KEY (`order_id`)
) ENGINE=InnoDB AUTO_INCREMENT=113 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

-- ----------------------------
-- Table structure for products
-- ----------------------------
DROP TABLE IF EXISTS `products`;
CREATE TABLE `products` (
  `pro_id` int(11) NOT NULL AUTO_INCREMENT,
  `pro_name` varchar(255) DEFAULT NULL,
  `pro_type` varchar(255) DEFAULT NULL,
  `pro_price` double(10,2) DEFAULT NULL,
  `pro_condition` varchar(255) DEFAULT NULL,
  `pro_discount` double(10,0) DEFAULT NULL,
  `pro_image` varchar(255) DEFAULT NULL,
  `pro_retailer` varchar(255) DEFAULT NULL,
  `pro_str_id` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci DEFAULT NULL,
  `pro_inventory` int(255) DEFAULT '100',
  `pro_status` int(255) DEFAULT '1',
  PRIMARY KEY (`pro_id`)
) ENGINE=InnoDB AUTO_INCREMENT=226 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

-- ----------------------------
-- Table structure for shipInfo
-- ----------------------------
DROP TABLE IF EXISTS `shipInfo`;
CREATE TABLE `shipInfo` (
  `ship_id` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci NOT NULL,
  `ship_address` varchar(255) NOT NULL,
  `ship_city` varchar(255) DEFAULT NULL,
  `ship_postcode` varchar(255) DEFAULT NULL,
  `ship_shipper_id` int(10) DEFAULT NULL,
  PRIMARY KEY (`ship_id`),
  KEY `ship_shipper_id` (`ship_shipper_id`),
  CONSTRAINT `shipinfo_ibfk_1` FOREIGN KEY (`ship_shipper_id`) REFERENCES `shipper` (`shipper_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

-- ----------------------------
-- Table structure for shipper
-- ----------------------------
DROP TABLE IF EXISTS `shipper`;
CREATE TABLE `shipper` (
  `shipper_id` int(10) NOT NULL AUTO_INCREMENT,
  `shipper_name` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`shipper_id`)
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

-- ----------------------------
-- Table structure for shoppingCart
-- ----------------------------
DROP TABLE IF EXISTS `shoppingCart`;
CREATE TABLE `shoppingCart` (
  `cart_id` int(11) NOT NULL AUTO_INCREMENT,
  `cart_item` varchar(255) DEFAULT NULL,
  `cart_price` double(10,2) DEFAULT NULL,
  `cart_user_name` varchar(255) DEFAULT NULL,
  `cart_status` int(255) DEFAULT NULL COMMENT '0: show , 1 : placed, do not show',
  PRIMARY KEY (`cart_id`)
) ENGINE=InnoDB AUTO_INCREMENT=118 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

-- ----------------------------
-- Table structure for users
-- ----------------------------
DROP TABLE IF EXISTS `users`;
CREATE TABLE `users` (
  `user_id` int(20) NOT NULL AUTO_INCREMENT,
  `user_name` varchar(255) NOT NULL COMMENT 'user name ',
  `user_password` varchar(255) NOT NULL,
  `user_type` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci DEFAULT NULL COMMENT 'contact/infrequent',
  `user_phone` varchar(255) DEFAULT NULL,
  `user_address` varchar(255) DEFAULT NULL,
  `user_city` varchar(255) DEFAULT NULL,
  `user_postcode` varchar(255) DEFAULT NULL,
  `user_cardNo` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci DEFAULT NULL,
  PRIMARY KEY (`user_id`)
) ENGINE=InnoDB AUTO_INCREMENT=21 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

-- ----------------------------
-- Table structure for usersContact
-- ----------------------------
DROP TABLE IF EXISTS `usersContact`;
CREATE TABLE `usersContact` (
  `user_id` int(11) DEFAULT NULL,
  `user_bill_account` varchar(255) DEFAULT NULL,
  KEY `user_id` (`user_id`),
  CONSTRAINT `user_id` FOREIGN KEY (`user_id`) REFERENCES `users` (`user_id`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

SET FOREIGN_KEY_CHECKS = 1;
